# sammy-web
Sammy is a simple CLI program with web pentesting tools
